/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.grupono1.system;

/**
 *
 * @author Franshesco Emmanuel Pascual Ramires
 * @time 07:47:25 PM
 * @date 30/08/2021
 * Codigo Tecnico: IN5BV
 * Carne: 2020343
 * Jornada: Vespertina
 */
public class Principal {
    
    public static void main(String[] args) {
        
    }

}
